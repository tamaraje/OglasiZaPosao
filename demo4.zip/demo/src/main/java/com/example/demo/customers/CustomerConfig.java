package com.example.demo.customers;

import com.example.demo.employers.Employer;
import com.example.demo.employers.EmployerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

@Configuration
public class CustomerConfig {
    @Bean
    CommandLineRunner commandLineRunner( EmployerRepository employerRepository, CustomerRepository customerRepository){
        return args -> {
            Customer cust = new Customer(
                    "Mina",
                    "Nikol",
                    LocalDate.of(2001, Month.FEBRUARY,14),
                    "nkolidmina@gmail.com",
                    "Cegarska",
                    "erisevergreen",
                    "codeeris",
                    true,
                    "0603709222",
                    "2 years"
            );
            Customer cust1 = new Customer(
                    "Joca",
                    "Vujk",
                    LocalDate.of(2003, Month.JANUARY,25),
                    "jovicavuk@gmail.com",
                    "Cegarska",
                    "jovicavuk",
                    "jovicavuk123",
                    true,
                    "0603769222",
                    "1 year"
            );
            List<Customer> list = new ArrayList<Customer>();
            list.add(cust);
            list.add(cust1);
            customerRepository.saveAll(list);
            Employer emp = new Employer(
                    "Lidl",
                    "Kg",
                    "prodaja",
                    "7249974",
                    "lidl@lidl.com",
                    "34000",
                    "Srbija",
                    "Save Petkovica",
                    "35546",
                    "lidlgo",
                    "khdfgjks",
                    true,
                    "gdgd/sffjk/hsgkg.com"
            );
            Employer emp1 = new Employer(
                    "Trnava",
                    "Kg",
                    "prodaja",
                    "628480",
                    "trnava@trnava.com",
                    "34000",
                    "Srbija",
                    "Sime Zivkovica",
                    "98284",
                    "trnavapromet",
                    "sfallkajgg",
                    true,
                    "gkjkk/hgghkjl/gfhgk.com"
            );
            List<Employer> list1 = new ArrayList<Employer>();
            list1.add(emp);
            list1.add(emp1);
            employerRepository.saveAll(list1);
        };
    }
}
