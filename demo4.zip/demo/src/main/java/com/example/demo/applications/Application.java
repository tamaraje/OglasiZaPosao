package com.example.demo.applications;
import com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer;

import javax.persistence.*;
import java.util.*;
import java.text.*;
@Entity
@Table
public class Application{
    @Id
    @SequenceGenerator(
            name = "application_sequence",
            sequenceName = "application_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "application_sequence"
    )
    private Long id;
    private Long idClient;
    private Long idJob;
    private String experience;
    private String education;

    public Application(Long idClient,Long idJob,String experience,String education) {
        this.idClient=idClient;
        this.idJob=idJob;
        this.education=education;
        this.experience=experience;
    }

    Date date = new Date( );
    SimpleDateFormat ft =new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

    public Application() {

    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getIdClient() {
        return idClient;
    }
    public void setIdClient(Long idClient) {
        this.idClient = idClient;
    }
    public Long getIdJob() {
        return idJob;
    }
    public void setIdJob(Long idJob) {
        this.idJob = idJob;
    }
    public String getExperience() {
        return experience;
    }
    public void setExperience(String experience) {
        this.experience = experience;
    }
    public String getEducation() {
        return education;
    }
    public void setEducation(String education) {
        this.education = education;
    }

    @Override
    public String toString() {
        return "Application{" +
                "id=" + id +
                ", idClient='" + idClient + '\'' +
                ", idJob='" + idJob + '\'' +
                ", experience='" + experience + '\'' +
                ", education='" + education + '\'' +
                '}';
    }
}