package com.example.demo.applications;

import com.example.demo.ads.Ad;
import com.example.demo.ads.AdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ApplicationService {
    private final ApplicationRepository applicationRepository;

    @Autowired
    public ApplicationService(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }
    public List<Application> getApplications(){
        return applicationRepository.findAll();
    }

    public void addNewApplication(Application application) {
        applicationRepository.save(application);
    }

    public void deleteApplication(Long id) {
        boolean b = applicationRepository.existsById(id);
        if(!b){
            throw new IllegalStateException("Application doesn't exists");
        }
        applicationRepository.deleteById(id);
    }
}