package com.example.demo.ads;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table
public class Ad {
    @Id
    @SequenceGenerator(
            name = "ad_sequence",
            sequenceName = "ad_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "ad_sequence"
    )
    private Long id;
    private String description;
    private Date dateOfPosting;
    private Date dateDeadline;
    private boolean workFromHome;
    private int viewCount;
    private int likeCount;
    private String job;
    private Long idJob;
    private Long idEmployer;


    public Ad(String description, Date dateDeadline, boolean workFromHome, int viewCount, int likeCount, String job, Long idEmployer,Long idJob) {
        this.description = description;
        this.dateDeadline = dateDeadline;
        this.workFromHome = workFromHome;
        this.viewCount = viewCount;
        this.likeCount = likeCount;
        this.job = job;
        this.idEmployer=idEmployer;
        this.idJob=idJob;
    }

    public Ad() {

    }

    public Long getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public Date getDateOfPosting() {
        return dateOfPosting;
    }

    public Date getDateDeadline() {
        return dateDeadline;
    }

    public boolean isWorkFromHome() {
        return workFromHome;
    }

    public int getViewCount() {
        return viewCount;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public String getJob() {
        return job;
    }

    public Long getIdJob(){return idJob;}

   public Long getIdEmployer(){return idEmployer;}

    public void setId(Long id) {
        this.id = id;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDateOfPosting(Date dateOfPosting) {
        this.dateOfPosting = dateOfPosting;
    }

    public void setDateDeadline(Date dateDeadline) {
        this.dateDeadline = dateDeadline;
    }

    public void setWorkFromHome(boolean workFromHome) {
        this.workFromHome = workFromHome;
    }

    public void setViewCount(int viewCount) {
        this.viewCount = viewCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public void setIdJob(Long idJob){this.idJob=idJob;}

    public void setIdEmployer(Long idEmployer){this.idEmployer=idEmployer;}

    @Override
    public String toString() {
        return "Ad{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", dateOfPosting=" + dateOfPosting +'\''+
                ", dateDeadline=" + dateDeadline +'\''+
                ", workFromHome=" + workFromHome +'\''+
                ", viewCount=" + viewCount +'\''+
                ", likeCount=" + likeCount +'\''+
                ", job='" + job + '\'' +
                ", idJob'"+idJob+'\''+
                ", idEmployer"+idEmployer+'\''+
                '}';
    }
}


