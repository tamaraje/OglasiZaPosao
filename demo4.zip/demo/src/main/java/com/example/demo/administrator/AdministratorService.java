package com.example.demo.administrator;

import com.example.demo.ads.Ad;
import com.example.demo.ads.AdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdministratorService {
    private final AdministratorRepository administratorRepository;

    @Autowired
    public AdministratorService(AdministratorRepository administratorRepository) {
        this.administratorRepository = administratorRepository;
    }
    public List<Administrator> getAdministrators(){
        return administratorRepository.findAll();
    }

    public void addNewAdministrator(Administrator administrator) {
        administratorRepository.save(administrator);
    }

    public void deleteAdministrator(Long id) {
        boolean b = administratorRepository.existsById(id);
        if(!b){
            throw new IllegalStateException("Administrator ne postoji");
        }
        administratorRepository.deleteById(id);
    }
}
